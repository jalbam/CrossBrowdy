$(function() {
  "use strict";
  prettyPrint();  
});
