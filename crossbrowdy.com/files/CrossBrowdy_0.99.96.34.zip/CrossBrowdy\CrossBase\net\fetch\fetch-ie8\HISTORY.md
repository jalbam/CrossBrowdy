1.5.0 / 2017-02-28
==================
* Fix self

1.4.3 / 2016-06-22
==================
* Compatibility when defining the global object, merged #5

1.4.2 / 2016-03-13
==================
* Fix request and response content-type different bug

1.4.1 / 2016-01-20
==================
* Make blob supporting different encoding, fixed #1

1.4.0 / 2015-12-09
==================
* Sync with github/fetch
* Fix promise resolve twice bug

1.3.1 / 2015-09-08
==================
* Use console.warn to log messages
